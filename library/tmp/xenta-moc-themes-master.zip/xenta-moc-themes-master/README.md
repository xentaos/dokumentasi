# About 
Xenta-MOC-Themes </br>
Author </br>
Created     : dindin@G41T-R3 </br>
Address     : Jakarta, Indonesia </br>
E-mail      : dindin_hernawan@yahoo.com </br>
Licenced    : GNU GPL 3.0 </br>
Screenshot  : <br>
<img src="https://github.com/dindinG41T-R3/Xenta-MOC-Themes/blob/master/img/thumbnail.png" >
</br>
# Install
Screenshot : </br>
<img src="https://github.com/dindinG41T-R3/Xenta-MOC-Themes/blob/master/img/install.png" >
</br> - Donwload file themes on /themes/Xenta and file config
</br> - File Xenta Move to your folder ~/.moc/themes/ example my home folder /home/dindin/.moc/themes/
</br> If not Exist themes create folder themes     
</br> - File config move to ~/moc/
</br> Ok, Just open terminal run "mocp" and look :)
</br> I hope enjoy, thank's
