# About 
Xenta-FLuxbox-Themes </br>
Author </br>
Created     : dindin@G41T-R3 </br>
Address     : Jakarta, Indonesia </br>
E-mail      : dindin_hernawan@yahoo.com </br>
Licenced    : GNU GPL 3.0 </br>
Screenshot  : <br>
<img src="https://github.com/dindinG41T-R3/xenta-fluxbox-themes/blob/master/img/Screenshot%20from%202017-03-17%2013-21-20.png" >
</br>
# Install
Screenshot : </br>
</br> I hope enjoy, thank's
