# awesome-classic
Blogger theme created by dindinG41TR3<br>
<img src="https://raw.githubusercontent.com/dindinG41TR3/awesome-classic/master/screenshot.png" alt="screenshot">
